#!/usr/bin/env bash
# Reproduction: a REAL static analyzer's CLEAN is input-class scoped.
# S = real public analyzers (clang static analyzer vs gcc -fanalyzer); X = execution oracle (ASan).
# Pinned reference env: clang 18.1.3, gcc 13.3.0, Ubuntu 24.04 (AddressSanitizer).
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
echo "== S (real static analyzers) =="
s_out="$("$HERE/s_checker.sh" "$HERE/target.c")"; echo "$s_out"
clang_v=$(echo "$s_out" | sed -n 's/.*clang=\([A-Z]*\).*/\1/p'); gcc_v=$(echo "$s_out" | sed -n 's/.*gcc=\([A-Z]*\).*/\1/p')
echo; echo "== X (execution oracle, ASan) =="
gcc -std=c11 -g -fsanitize=address "$HERE/harness/main.c" "$HERE/target.c" -o "$HERE/.x"
set +e; x_out="$("$HERE/.x" 2>&1)"; xrc=$?; set -e; rm -f "$HERE/.x"
benign_clean=$(echo "$x_out" | grep -qE "benign .*rc=0" && echo yes || echo no)
x_oob=$(echo "$x_out" | grep -qE "parse_record .*target\.c:21" && echo yes || echo no)
echo "$x_out" | grep -E "benign|adversarial|heap-buffer-overflow|WRITE of size|parse_record .*target.c:21|done" || true
echo; echo "== standard readout (computed from the outputs above) =="
echo "  claim SW-001 (parse_record, dest-size integer truncation)"
echo "    input-class=benign      : S(clang)=$clang_v  X=CLEAN(covered,line)         -> certify_clean (scope: benign input-class, clang)"
echo "    input-class=adversarial : S(clang)=$clang_v  X=BUG(covered,input-class)@target.c:21 -> clean does NOT transfer across input-class"
echo "    disagreement            : S(gcc -fanalyzer)=$gcc_v  (a real second checker DOES flag it) -> this is a checker-vs-checker + checker-vs-exec cell"
echo "    control grade: X positive-controlled by the adversarial input-class itself producing the OOB; coverage depth: line(benign) / input-class(adversarial)"
echo
# VERDICT gated on real outputs: clang CLEAN, gcc BUG, X benign-clean AND X oob-on-adversarial
if [ "$clang_v" = CLEAN ] && [ "$gcc_v" = BUG ] && [ "$benign_clean" = yes ] && [ "$x_oob" = yes ] && [ "$xrc" != 0 ]; then
  echo "VERDICT: NON-TRANSFERABILITY REPRODUCED (software) — clang-CLEAN is input-class scoped; gcc -fanalyzer and ASan both flag target.c:21."
else
  echo "VERDICT: UNEXPECTED (clang=$clang_v gcc=$gcc_v benign_clean=$benign_clean x_oob=$x_oob xrc=$xrc)"; exit 1
fi
